ALTER TABLE /*$wgDBprefix*/archive
  ADD ar_content_format varbinary(64) DEFAULT NULL;
