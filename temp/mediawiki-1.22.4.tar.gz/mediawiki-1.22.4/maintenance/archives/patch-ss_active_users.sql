-- More statistics, for version 1.14

ALTER TABLE /*$wgDBprefix*/site_stats ADD ss_active_users bigint default '-1';
