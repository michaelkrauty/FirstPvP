-- index for ipblocks.ipb_parent_block_id
CREATE INDEX /*i*/ipb_parent_block_id ON /*_*/ipblocks (ipb_parent_block_id);
